
public class InvalidInputException extends Exception

{
	InvalidInputException(String s)
	{
		super(s);
	}
	
}

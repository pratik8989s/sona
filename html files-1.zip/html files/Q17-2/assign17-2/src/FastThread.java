
public class FastThread implements Runnable
{

	public synchronized void m1()
	{
		for(int i=30;i<=30;i++)
		{
			for(int j=1;j<=10;j++ )
			{
				System.out.println( i+"*"+j +"="+(i*j));
			}
		}
	}
	
	public void run() {
		
		m1();
		
	}
	
}

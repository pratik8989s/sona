
public class MultiThreaded
{
	public static void main(String args[]) throws InterruptedException
	{
		
		
		FastThread fast = new FastThread();
		Thread thread3 = new Thread(fast);
		MediumThread medium = new MediumThread(thread3);
		Thread thread2 = new Thread(medium);
		SlowThread slow = new SlowThread(thread2);
		Thread thread1 = new Thread(slow);
		
		thread1.setPriority(1);
		thread2.setPriority(5);
		thread3.setPriority(10);
		thread3.start();
		thread2.start();
		thread1.start();
		
		Thread.sleep(1000);
	
		
	
		System.out.println("Finished Printing Tables of 10,20,30");
	}

}

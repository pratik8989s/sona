
class InvalidGradeException extends Exception {
String message;



	public InvalidGradeException(String s) {
		this.message=s;

	}public String toString(){
		return message;

}

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class A {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		char a='c';
		String j="kk";
		char b=(char) (a+32);
		j=j+b;
		System.out.println(j);
		BufferedWriter bw= new BufferedWriter(new FileWriter("dd.txt"));
		bw.write("zzzz");

	}

}

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;


public class CopyFile 
{
	public static void main(String[] args) throws IOException,FileNotFoundException
	{
	
		String filename=args[0];
		BufferedWriter out1 = new BufferedWriter(new FileWriter(filename));
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter some content to file:");
		String s=br.readLine();
		out1.write(s);
		out1.close();
		
		String filename1=args[1];
		BufferedWriter bw= new BufferedWriter(new FileWriter(filename1));
		BufferedReader br1=new BufferedReader(new FileReader(filename));
		
		String str;
		String append="";
		
		while((str=br1.readLine())!=null)
		{
			
			int length=str.length();
			for(int i=0;i<length;i++)
			{
				if(str.charAt(i)>=65 && str.charAt(i)<=90)
				{
					char c=(char)(str.charAt(i)+32);
					append=append+c;
				}
				else if(str.charAt(i)>=97 && str.charAt(i)<=122)
				{
					char b=(char)(str.charAt(i)-32);
					append=append+b;
				}
				else
				{
					append=append+str.charAt(i);
				}
			}
			System.out.println(append);
			bw.write(append);
			bw.flush();
		}
		
	}

}

package com.employee;

public abstract class Employee 
{
	
	int empId;     	           
	String empName;	        	  
	DateofJoin dateOfJoin;   
	double basicSal;
	public Employee(int empId, String empName, DateofJoin dateOfJoin,
			double basicSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.dateOfJoin = dateOfJoin;
		this.basicSal = basicSal;
	}	
	public void showDetails()
	{
		System.out.println("Emp ID:"+empId+"\nEmp Name:"+empName+"\nBasic Sal:"+basicSal);
	}
	public abstract void calcSal();

	

}

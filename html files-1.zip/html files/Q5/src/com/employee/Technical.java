package com.employee;

import java.util.Scanner;

public class Technical extends Employee
{
	public Technical(int empId, String empName, DateofJoin dateOfJoin,
			double basicSal) 
	{
		super(empId, empName, dateOfJoin, basicSal);
		
	}

	public String jobDesc="Technical";
	public String grade="T";
	float salary;
	
	 public void showDetails()
	{
						
		System.out.println("Enter emp ID:"+empId);
			
		System.out.println("Enter emp name:"+empName);
			
		System.out.println("Enter basic salary:"+basicSal);
						
		System.out.println("Job Desc:"+jobDesc);
			
		System.out.println("Grade:"+grade);
		System.out.println("Salary of "+empName+" having empID-"+empId+" is: "+salary);
	}
	
	public void  calcSal()
	{
		salary=(float)(basicSal+ (basicSal*0.10));
		
	}
}

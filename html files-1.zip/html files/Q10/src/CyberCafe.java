import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
public class CyberCafe {
	String cafeName;
	String address;
	int membersCount;
	int ratePerHour;
	static ArrayList<CyberCafe> al= new ArrayList<CyberCafe>();
	public CyberCafe(String cafeName, String address, int membersCount,
			int ratePerHour) {
		super();
		this.cafeName = cafeName;
		this.address = address;
		this.membersCount = membersCount;
		this.ratePerHour = ratePerHour;
	}
	public static void main(String args[]) throws NumberFormatException, IOException {
		System.out.println("enter the no.of objects");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int noOfObjects = Integer.parseInt(br.readLine());
		
		for (int i = 0; i < noOfObjects; i++) {
			
			System.out.println("enter "+(i+1)+" cafename");
			String cafeName = br.readLine();
			System.out.println("enter address");
			String address = br.readLine();
			System.out.println("enter memberCount");
			int membersCount = Integer.parseInt(br.readLine());
			System.out.println("enter ratePerHour");
			int ratePerHour = Integer.parseInt(br.readLine());
			 CyberCafe c= new CyberCafe(cafeName, address, membersCount, ratePerHour);
		    al.add(c);
		   }
		 System.out.println("enter name of a cafe which you want to search");
			String cafe1= br.readLine();
			Search1 search1=new Search1(al,cafe1);
			search1.start();
			
			String cafe2= br.readLine();
			Search2 search2=new Search2(al,cafe2);
			search2.start();
	}
}

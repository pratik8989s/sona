package com.mobile.exp;

public class UnavailableServiceException extends Exception{
public UnavailableServiceException()
{
	super("UnavailableServiceException");
}
}

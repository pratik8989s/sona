

public class Item {
 int itemId;
 String itemName;

	public Item(int itemId, String itemName) {
	super();
	this.itemId = itemId;
	this.itemName = itemName;
}
	// method to display the item details
		public void disply() {
			System.out.println("Item id :" + this.itemId + "  itemName :"
					+ this.itemName);
		}
}


public class MultiThreadTest {
	public static void main(String[] args) {
		//creating the object for First Thread
		FirstThread first = new FirstThread();
		//creating the object for Second Thread
		SecondThread second = new SecondThread(first);

		first.start();// first thread started
		second.start();// second thread started
	}
}

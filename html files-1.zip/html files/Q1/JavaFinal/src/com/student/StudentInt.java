package com.student;

public interface StudentInt {
	public abstract void readStudInfo();

	public abstract void calcTotal();

	public abstract void printStudInfo();
}

import java.util.ListIterator;
public class SecondThread extends Thread {
	FirstThread first;// To get the all details from FirstThread
	SecondThread(FirstThread ff) {
		this.first = ff;
	}

	public void run() {
		synchronized (first) {
			ListIterator li = first.al.listIterator();
			System.out.println("Second thread get started to print the item details\n");
			System.out.println("The Item Details are");
			//forward traversing using the listIterator
			while (li.hasNext()) {
				Item item = (Item) (li.next());// type casting into the Item
												// object
				item.disply();// calling the display method in Item class to get
								// the details
			}
		}
	}
}
package com.airline;

public class Domestic extends Airlines{
	private String zonalCode;
	private double ticketCost;
public Domestic(String airId, String source, String destination,String zonalCode) {
		super(airId, source, destination);
		this.zonalCode=zonalCode;
		switch(this.zonalCode){
		case "Z001":this.ticketCost=3500;
		break;
		case "Z002":this.ticketCost=4000;
		break;
		case "Z003":this.ticketCost=4500;
		break;
		}
		}

@Override
public void bookTicket(int noOftickets) {
	double totalCost = noOftickets*ticketCost;
	System.out.println("total ticket cost is.."+totalCost);
	
}



}

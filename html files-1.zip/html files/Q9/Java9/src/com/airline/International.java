package com.airline;

public class International extends Airlines {
	private String countryCode;
	private double ticketCost;
	public International(String airId, String source, String destination,String countryCode) {
		super(airId, source, destination);
		this.countryCode=countryCode;
		switch(this.countryCode){
		case "I001":this.ticketCost=25000;
		break;
		case "I002":this.ticketCost=36000;
		break;
		case "I003":this.ticketCost=38000;
		break;
		}
	}
	@Override
	public void bookTicket(int noOftickets) {
		double totalCost = noOftickets*ticketCost;
		System.out.println("total ticket cost is.."+totalCost);
		
	}

}

package com.techm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

public class TestOrder {

	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter cutomer ID:");
		int customerID=Integer.parseInt(br.readLine());
		System.out.println("Enter cutomer Name:");
		String customerName=br.readLine();
		Customer customer=new Customer(customerID,customerName);
		System.out.println("Enter the number of orders:");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter order ID:");
			int orderID=Integer.parseInt(br.readLine());
			System.out.println("Enter order Name:");
			String orderName=br.readLine();
			System.out.println("Enter order Description:");
			String orderDescription=br.readLine();
			System.out.println("Enter order Status:");
			String orderStatus=br.readLine();
			Order order=new Order(orderID,orderName,orderDescription);
			order.setOrderStatus(orderStatus);
			if(order.getOrderStatus().equals("None")!=true)
			{
						customer.addNewOrder(order);
			}
		}
		
		ArrayList <Order> orderList=customer.getOrderList();
		if(orderList.size()!=0)
		{
			System.out.println("Enter order id to change status:");
			int changeID=Integer.parseInt(br.readLine());
			System.out.println("Enter new status:");
			String changeStatus=br.readLine();
			customer.changeOrderStatus(changeID, changeStatus);
			Iterator itr=orderList.iterator();
			System.out.println("OrderID"+"\t"+"OrderType"+"\t"+"OrderDescription"+"\t"+"OrderStatus");
			while(itr.hasNext())
			{
				Order order=(Order)itr.next();
				System.out.println(order.getOrderId()+"\t"+order.getOrderType()+"\t"+order.getOrderDescription()+"\t"+order.getOrderStatus());
			}
		}
		else
		{
			System.out.println("No orders found");
		}

	}

}

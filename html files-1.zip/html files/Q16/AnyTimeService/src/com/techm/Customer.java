package com.techm;

import java.util.ArrayList;
import java.util.Iterator;

public class Customer {

	int customerId;
	String customerName;
	ArrayList <Order> orderList=new ArrayList();
	public Customer(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
	}
	public void addNewOrder(Order order) 
	{
		orderList.add(order);
	}
	public ArrayList getOrderList()
	{
		/*Iterator itr=orderList.iterator();
		while(itr.hasNext())
		{
			Order order=(Order) itr.next();
				System.out.println(order.getOrderId()+"\t"+order.getOrderType()+"\t"+order.getOrderDescription()+"\t"+order.getOrderStatus());
		}*/
		return orderList;
	}
	public void changeOrderStatus (int orderID, String status)
	{
		Iterator itr=orderList.iterator();
		while(itr.hasNext())
		{
			Order order=(Order) itr.next();
			if(order.getOrderId()==orderID)
			{
				order.setOrderStatus(status);
			}
			else
			{
				System.out.println("Order Id not found");
			}
		}
		
	}
}
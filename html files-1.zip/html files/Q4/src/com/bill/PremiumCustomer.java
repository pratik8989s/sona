package com.bill;

import java.util.Scanner;

public class PremiumCustomer extends Customer
{
	int billNo;
	float billAmount;
	
		
	public PremiumCustomer(int customerID, String customerName, long mobileNo,
			int billNo) {
		super(customerID, customerName, mobileNo);
		this.billNo = (int)Math.round(Math.random()*10);
	}
	public int getBillNo() {
		return billNo;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public double calculateBill ( int minutes )  
	{
		
		if(minutes<=30)
		{
			billAmount=minutes;
		}
		else
		{
			billAmount=(float) (30+((minutes-30)*0.5));
		}
		return billAmount;
		
	}
	public String toString() {
		return "Customer Id..."+customerID+"\nCustomerName... "+customerName+"\nMobile No..."+mobileNo+"\nBill No..."+billNo+"\nTotal Bill amount..."+billAmount;
	}
	
	
}

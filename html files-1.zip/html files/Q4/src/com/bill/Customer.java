package com.bill;

public abstract class Customer 
{
	public int customerID;
	public String customerName;
	public long mobileNo;
	
	public Customer(int customerID, String customerName, long mobileNo) {
		super();
		this.customerID=customerID;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	
		
	public double calculateBill (int minutes) {
		return 0;
	}
}


public class MoreThanFiveException extends RuntimeException
{
	public MoreThanFiveException() 
	{
		super("You didnot give five numbers");
	}
	
	
}

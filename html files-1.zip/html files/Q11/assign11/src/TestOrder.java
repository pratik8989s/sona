
public class TestOrder {

	public static void main(String[] args) {
		Order o1=new Order();
		Order o2=new Order();
		o1.acceptData();
		o1.dispOrder();

	}

}

package com.adityabirla;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class TestClinic {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter no of doctors:");
		int num = scan.nextInt();
		Doctor doc[] = new Doctor[num];
		for (int i = 0; i < num; i++) {
			System.out.println("Enter doctor ID for the  doctor ");
			String docId = scan.next();
			System.out.println("Enter the doctor name ");
			String docName = scan.next();
			doc[i] = new Doctor();
			doc[i].setDocId(docId);
			doc[i].setDocName(docName);
		}
		int count[]=new int[num];
		for(int i=0;i<num;i++)
		{
				System.out.println("Enter number of appointments for doctor"+(i+1));
				int n=scan.nextInt();
				count[i]=n;
				for(int j=0;j<n;j++)
				{
					Appointment ap1 = new Appointment();
					System.out.println("Enter appointment date:(in dd/MM/yyyy format) ");
					DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
					try {
						ap1.setAppDate(df.parse(scan.next()));
					} catch (ParseException e) {
						e.printStackTrace();
					}
					System.out.println("Enter number of patients: ");
					int tempNum = scan.nextInt();
					if (tempNum < 1 || tempNum > 15) {
						try {
							throw new InvalidDataException("Invalid Input Exception");
						} catch (InvalidDataException ide) {
							System.out.println(ide.getMessage());
						}
					} else {

						ap1.setNoOfPatients(tempNum);
						doc[i].addAppointment(ap1);
					}
				}
		}
		
		for(int i=0;i<num;i++)
		{
			System.out.println("count"+count[i]);
		}

		System.out.println("Enter a doctor ID to get details ");
		String tempDocId = scan.next();
		int c=0;
		for(int i=0;i<num;i++)
		{
		if(tempDocId.equals(doc[i].getDocId())) {
			System.out.println("Appointment details of the doctor: ");
			doc[i].printAppointment();
		}
		c++;
		}

		if(c==0)
		{
			System.out.println("Doctor ID doesn't exist");
		}
		scan.close();

	}

}
